import mongoose from 'mongoose'

const translationHistorySchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    originalText: { type: String, required: true },
    translatedText: { type: String, required: true },
    fromLang: { type: String, required: true },
    toLang: { type: String, required: true }
  },
  { timestamps: true }
)

export default mongoose.model('TranslationHistory', translationHistorySchema)
