import mongoose from 'mongoose'

const courseSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    level: { type: String, enum: ['Beginner', 'Intermediate', 'Advanced', 'Pro'], required: true },
    description: { type: String, default: '' },
    price: { type: Number, required: true },
    lessons: { type: Number, required: true },
    features: [{ type: String }],
    emoji: { type: String, default: '📘' },
    thumbnailUrl: { type: String, default: '' }
  },
  { timestamps: true }
)

export default mongoose.model('Course', courseSchema)
