import mongoose from 'mongoose'

const progressSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    coursesEnrolled: { type: Number, default: 0 },
    lessonsCompleted: { type: Number, default: 0 },
    streakDays: { type: Number, default: 0 },
    lastActiveDate: { type: Date, default: Date.now },
    certificates: { type: Number, default: 0 },
    overallProgress: { type: Number, default: 0, min: 0, max: 100 }
  },
  { timestamps: true }
)

export default mongoose.model('Progress', progressSchema)
