import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import morgan from 'morgan'
import { connectDB } from './config/db.js'

import authRoutes from './routes/auth.js'
import translateRoutes from './routes/translate.js'
import courseRoutes from './routes/courses.js'
import progressRoutes from './routes/progress.js'
import historyRoutes from './routes/history.js'
import userRoutes from './routes/user.js'

const app = express()

app.use(
  cors({
    origin: (process.env.CLIENT_ORIGIN || 'http://localhost:5173').split(',')
  })
)
app.use(express.json())
app.use(morgan('dev'))

app.get('/api/health', (req, res) => res.json({ status: 'ok' }))

app.use('/api/auth', authRoutes)
app.use('/api/translate', translateRoutes)
app.use('/api/courses', courseRoutes)
app.use('/api/progress', progressRoutes)
app.use('/api/history', historyRoutes)
app.use('/api/user', userRoutes)

// 404 handler
app.use((req, res) => res.status(404).json({ message: 'Route not found.' }))

// Global error handler
app.use((err, req, res, next) => {
  console.error(err)
  res.status(500).json({ message: 'Something went wrong on the server.' })
})

const PORT = process.env.PORT || 5000

connectDB().then(() => {
  app.listen(PORT, () => console.log(`LinguaHub API running on http://localhost:${PORT}`))
})
