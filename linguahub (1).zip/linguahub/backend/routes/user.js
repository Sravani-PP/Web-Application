import { Router } from 'express'
import User from '../models/User.js'
import { requireAuth } from '../middleware/auth.js'

const router = Router()

router.get('/me', requireAuth, async (req, res) => {
  const user = await User.findById(req.userId)
  if (!user) return res.status(404).json({ message: 'User not found.' })
  res.json(user.toSafeObject())
})

router.patch('/me', requireAuth, async (req, res) => {
  const allowed = ['name', 'avatarUrl']
  const updates = {}
  for (const key of allowed) {
    if (req.body[key] !== undefined) updates[key] = req.body[key]
  }
  const user = await User.findByIdAndUpdate(req.userId, updates, { new: true })
  res.json(user.toSafeObject())
})

export default router
