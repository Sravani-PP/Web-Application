import { Router } from 'express'
import Course from '../models/Course.js'
import Enrollment from '../models/Enrollment.js'
import Progress from '../models/Progress.js'
import { requireAuth } from '../middleware/auth.js'

const router = Router()

router.get('/', async (req, res) => {
  const courses = await Course.find().sort({ price: 1 })
  res.json(courses)
})

router.get('/:id', async (req, res) => {
  const course = await Course.findById(req.params.id)
  if (!course) return res.status(404).json({ message: 'Course not found.' })
  res.json(course)
})

router.post('/:id/enroll', requireAuth, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id)
    if (!course) return res.status(404).json({ message: 'Course not found.' })

    const enrollment = await Enrollment.findOneAndUpdate(
      { user: req.userId, course: course._id },
      { $setOnInsert: { currentLesson: 1, progressPercent: 0 } },
      { upsert: true, new: true }
    )

    await Progress.findOneAndUpdate(
      { user: req.userId },
      { $inc: { coursesEnrolled: 1 } },
      { upsert: true }
    )

    res.status(201).json(enrollment)
  } catch (err) {
    res.status(500).json({ message: 'Enrollment failed.', error: err.message })
  }
})

export default router
