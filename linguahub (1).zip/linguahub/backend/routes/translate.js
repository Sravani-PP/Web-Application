import { Router } from 'express'
import fetch from 'node-fetch'
import jwt from 'jsonwebtoken'
import TranslationHistory from '../models/TranslationHistory.js'

const router = Router()

// Optional auth: if a valid token is present we save history, otherwise
// translation still works for guests (dashboard demo mode).
function attachUserIfPresent(req) {
  const header = req.headers.authorization
  if (!header || !header.startsWith('Bearer ')) return null
  try {
    const decoded = jwt.verify(header.split(' ')[1], process.env.JWT_SECRET)
    return decoded.id
  } catch {
    return null
  }
}

router.post('/', async (req, res) => {
  const { text, from, to } = req.body
  if (!text || !from || !to) {
    return res.status(400).json({ message: 'text, from and to are required.' })
  }

  try {
    // ---- Provider call -------------------------------------------------
    // Swappable: replace this block with Google/Azure/DeepL as needed —
    // the rest of the route (auth + history save) stays the same.
    const response = await fetch(process.env.LIBRETRANSLATE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        q: text,
        source: from,
        target: to,
        format: 'text',
        api_key: process.env.LIBRETRANSLATE_API_KEY || undefined
      })
    })

    if (!response.ok) {
      throw new Error(`Translation provider responded with ${response.status}`)
    }

    const data = await response.json()
    const translatedText = data.translatedText
    // ---------------------------------------------------------------------

    const userId = attachUserIfPresent(req)
    if (userId) {
      await TranslationHistory.create({
        user: userId,
        originalText: text,
        translatedText,
        fromLang: from,
        toLang: to
      })
    }

    res.json({ translatedText })
  } catch (err) {
    res.status(502).json({ message: 'Translation provider error.', error: err.message })
  }
})

export default router
