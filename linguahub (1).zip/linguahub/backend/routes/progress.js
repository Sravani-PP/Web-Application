import { Router } from 'express'
import Progress from '../models/Progress.js'
import { requireAuth } from '../middleware/auth.js'

const router = Router()

router.get('/', requireAuth, async (req, res) => {
  let progress = await Progress.findOne({ user: req.userId })
  if (!progress) {
    progress = await Progress.create({ user: req.userId })
  }
  res.json(progress)
})

router.patch('/', requireAuth, async (req, res) => {
  const allowed = ['lessonsCompleted', 'streakDays', 'certificates', 'overallProgress']
  const updates = {}
  for (const key of allowed) {
    if (req.body[key] !== undefined) updates[key] = req.body[key]
  }
  const progress = await Progress.findOneAndUpdate(
    { user: req.userId },
    { $set: updates, lastActiveDate: new Date() },
    { new: true, upsert: true }
  )
  res.json(progress)
})

export default router
