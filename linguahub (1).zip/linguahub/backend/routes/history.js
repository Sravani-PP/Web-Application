import { Router } from 'express'
import TranslationHistory from '../models/TranslationHistory.js'
import { requireAuth } from '../middleware/auth.js'

const router = Router()

router.get('/', requireAuth, async (req, res) => {
  const items = await TranslationHistory.find({ user: req.userId })
    .sort({ createdAt: -1 })
    .limit(50)
  res.json(items)
})

router.delete('/', requireAuth, async (req, res) => {
  await TranslationHistory.deleteMany({ user: req.userId })
  res.json({ message: 'History cleared.' })
})

export default router
