import 'dotenv/config'
import { connectDB } from '../config/db.js'
import Course from '../models/Course.js'
import mongoose from 'mongoose'

const courses = [
  {
    title: 'Speak & Learn Basics',
    level: 'Beginner',
    description: 'Start from the basics of any language.',
    price: 499,
    lessons: 20,
    emoji: '👋',
    features: ['Basic speaking', 'Vocabulary', 'Daily conversations']
  },
  {
    title: 'Build Your Skills',
    level: 'Intermediate',
    description: 'Improve vocabulary, grammar and conversations.',
    price: 999,
    lessons: 40,
    emoji: '📗',
    features: ['Grammar', 'Listening', 'Reading']
  },
  {
    title: 'Fluent Conversations',
    level: 'Advanced',
    description: 'Speak naturally in real-life situations.',
    price: 1999,
    lessons: 60,
    emoji: '💬',
    features: ['Fluency', 'Real-life conversations', 'Writing']
  },
  {
    title: 'Professional Mastery',
    level: 'Pro',
    description: 'Business, IELTS, TOEFL & advanced programs.',
    price: 2999,
    lessons: 80,
    emoji: '💼',
    features: ['Business communication', 'Interview preparation', 'Certification prep']
  }
]

async function run() {
  await connectDB()
  await Course.deleteMany({})
  await Course.insertMany(courses)
  console.log(`Seeded ${courses.length} courses.`)
  await mongoose.disconnect()
  process.exit(0)
}

run().catch((err) => {
  console.error(err)
  process.exit(1)
})
