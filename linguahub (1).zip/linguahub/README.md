# LinguaHub – Learn, Translate & Connect

A full-stack language-learning SaaS dashboard: translator, courses, guidance,
availability, and progress tracking. Built with React + Vite + Tailwind on
the frontend and Node/Express + MongoDB on the backend.

```
linguahub/
├── frontend/   React + Vite + Tailwind SPA
└── backend/    Node + Express + MongoDB API
```

## 1. Prerequisites

- Node.js 18+
- A MongoDB database — either:
  - Local MongoDB running on `mongodb://127.0.0.1:27017`, or
  - A free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster (recommended if you don't want to install MongoDB locally)

## 2. Backend setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env: set MONGO_URI (and JWT_SECRET to any long random string)
npm run seed     # loads the 4 sample courses into your database
npm run dev      # starts the API on http://localhost:5000
```

Verify it's running: open http://localhost:5000/api/health — you should see `{"status":"ok"}`.

### Translation provider

The `/api/translate` route calls [LibreTranslate](https://libretranslate.com/)
by default (`LIBRETRANSLATE_URL` in `.env`). The public instance is
rate-limited and can be slow/unreliable — for real use, either:

- Run your own LibreTranslate instance (`docker run -p 5001:5000 libretranslate/libretranslate`)
  and point `LIBRETRANSLATE_URL` at it, or
- Swap the provider call in `backend/routes/translate.js` for Google
  Translate, Azure Translator, or DeepL — the rest of the route
  (auth check + history save) doesn't need to change.

## 3. Frontend setup

```bash
cd frontend
npm install
npm run dev       # starts the app on http://localhost:5173
```

The Vite dev server proxies `/api/*` requests to `http://localhost:5000`
(configured in `vite.config.js`), so make sure the backend is running first.

Open http://localhost:5173, sign up for an account, and you'll land on the
dashboard.

## 4. Building for production

```bash
cd frontend && npm run build     # outputs static files to frontend/dist
cd backend  && npm start         # runs the API with node (no watch mode)
```

Deploy `frontend/dist` to any static host (Vercel, Netlify, S3) and the
`backend` folder to any Node host (Render, Railway, Fly.io), pointing
`CLIENT_ORIGIN` in the backend `.env` at your deployed frontend URL.

## 5. What's implemented

- **Auth**: signup/login with JWT, bcrypt-hashed passwords, "remember me",
  show/hide password, client-side validation.
- **Translator**: from/to language pickers (12 languages), swap, copy,
  text-to-speech playback, character counter, popular-pair shortcuts, saves
  history for logged-in users.
- **Courses**: 4 tiers (Beginner ₹499 → Pro ₹2,999) seeded in MongoDB,
  served via `/api/courses`.
- **Guidance & Support / Availability**: contact card and learning-mode /
  location picker (static content — wire up to real data as needed).
- **Progress**: courses enrolled, lessons completed, streak, certificates,
  overall progress bar, backed by a `Progress` model per user.
- **Recent Translations**: live-updating history list backed by
  `TranslationHistory`.
- **Responsive layout**: sidebar becomes a drawer on mobile, cards reflow to
  1/2/3 columns.

## 6. What you'll likely want to extend

- Real lesson content and video/audio playback for "Continue Learning".
- Payment integration (Razorpay/Stripe) before enrollment is treated as paid.
- Admin panel for managing courses.
- Push/email notifications instead of the placeholder bell icon.
