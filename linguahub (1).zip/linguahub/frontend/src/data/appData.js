export const LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', flag: '🇮🇳' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' }
]

// Languages shown in the header globe switcher (UI language, not translator language)
export const UI_LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'ja', name: '日本語' },
  { code: 'hi', name: 'हिन्दी' },
  { code: 'te', name: 'తెలుగు' }
]

export const POPULAR_PAIRS = [
  { from: 'en', to: 'hi', label: 'English → Hindi' },
  { from: 'en', to: 'te', label: 'English → Telugu' },
  { from: 'en', to: 'ja', label: 'English → Japanese' },
  { from: 'hi', to: 'en', label: 'Hindi → English' },
  { from: 'te', to: 'en', label: 'Telugu → English' },
  { from: 'en', to: 'fr', label: 'English → French' }
]

export const COURSES = [
  {
    id: 'beginner',
    level: 'Beginner',
    language: 'Spanish',
    mode: 'Online',
    platform: 'LinguaHub',
    rating: 4.6,
    badgeColor: 'bg-emerald-500',
    buttonColor: 'bg-emerald-500 hover:bg-emerald-600',
    price: 499,
    lessons: 20,
    emoji: '👋',
    avatarBg: 'from-sky-100 to-sky-200',
    title: 'Speak & Learn Basics',
    description: 'Start from the basics of any language.',
    features: ['Basic speaking', 'Vocabulary', 'Daily conversations']
  },
  {
    id: 'intermediate',
    level: 'Intermediate',
    language: 'French',
    mode: 'Online',
    platform: 'LinguaHub',
    rating: 4.7,
    badgeColor: 'bg-blue-500',
    buttonColor: 'bg-blue-500 hover:bg-blue-600',
    price: 999,
    lessons: 40,
    emoji: '📗',
    avatarBg: 'from-orange-100 to-orange-200',
    title: 'Build Your Skills',
    description: 'Improve vocabulary, grammar and conversations.',
    features: ['Grammar', 'Listening', 'Reading']
  },
  {
    id: 'advanced',
    level: 'Advanced',
    language: 'German',
    mode: 'Hybrid',
    platform: 'LinguaHub',
    rating: 4.5,
    badgeColor: 'bg-orange-500',
    buttonColor: 'bg-orange-500 hover:bg-orange-600',
    price: 1999,
    lessons: 60,
    emoji: '💬',
    avatarBg: 'from-amber-100 to-amber-200',
    title: 'Fluent Conversations',
    description: 'Speak naturally in real-life situations.',
    features: ['Fluency', 'Real-life conversations', 'Writing']
  },
  {
    id: 'pro',
    level: 'Pro',
    language: 'Japanese',
    mode: 'Offline',
    platform: 'LinguaHub',
    rating: 4.8,
    badgeColor: 'bg-purple-600',
    buttonColor: 'bg-purple-600 hover:bg-purple-700',
    price: 2999,
    lessons: 80,
    emoji: '💼',
    avatarBg: 'from-slate-200 to-slate-300',
    title: 'Professional Mastery',
    description: 'Business, IELTS, TOEFL & advanced programs.',
    features: ['Business communication', 'Interview preparation', 'Certification prep']
  },
  {
    id: 'spanish-zero-hero',
    level: 'Beginner',
    language: 'Spanish',
    mode: 'Online',
    platform: 'Coursera',
    rating: 4.7,
    badgeColor: 'bg-emerald-500',
    buttonColor: 'bg-emerald-500 hover:bg-emerald-600',
    price: 1299,
    lessons: 120,
    emoji: '🇪🇸',
    avatarBg: 'from-rose-100 to-rose-200',
    title: 'Complete Spanish Course – Zero to Hero',
    description: 'Learn Spanish step by step and become fluent.',
    features: ['Structured path', 'Native audio', 'Certificate included']
  },
  {
    id: 'japanese-basics',
    level: 'Beginner',
    language: 'Japanese',
    mode: 'Online',
    platform: 'LinguaHub',
    rating: 4.6,
    badgeColor: 'bg-emerald-500',
    buttonColor: 'bg-emerald-500 hover:bg-emerald-600',
    price: 799,
    lessons: 30,
    emoji: '🎌',
    avatarBg: 'from-red-100 to-red-200',
    title: 'Japanese for Beginners',
    description: 'Hiragana, katakana, and everyday conversation.',
    features: ['Writing systems', 'Listening practice', 'Culture notes']
  }
]

export const LEVELS = ['Beginner', 'Intermediate', 'Advanced', 'Pro']
export const MODES_FILTER = ['Online', 'Offline', 'Hybrid']
export const COURSE_LANGUAGES = ['Spanish', 'French', 'German', 'Japanese']

export const ENROLLED_COURSES = [
  {
    id: 'enr-1',
    title: 'Spanish for Beginners',
    thumbnail: 'https://images.unsplash.com/photo-1509053554192-6e5a3e021a55?w=200&h=200&fit=crop',
    currentLesson: 'Lesson 6 of 20',
    completedLessons: 5,
    totalLessons: 20,
    progress: 30,
    lastStudied: 'Today, 9:30 AM'
  },
  {
    id: 'enr-2',
    title: 'French Essentials',
    thumbnail: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=200&h=200&fit=crop',
    currentLesson: 'Lesson 10 of 25',
    completedLessons: 10,
    totalLessons: 25,
    progress: 40,
    lastStudied: 'Yesterday, 7:15 PM'
  },
  {
    id: 'enr-3',
    title: 'Japanese Basics',
    thumbnail: 'https://images.unsplash.com/photo-1528360983277-13d401cdc186?w=200&h=200&fit=crop',
    currentLesson: 'Lesson 3 of 18',
    completedLessons: 3,
    totalLessons: 18,
    progress: 15,
    lastStudied: '2 days ago'
  }
]

export const RECENT_ACTIVITY = [
  { id: 1, text: 'Completed Lesson 5 · Spanish for Beginners', time: '1 hour ago', type: 'done' },
  { id: 2, text: 'Practiced Spanish vocabulary · 15 new words learned', time: 'Today', type: 'practice' },
  { id: 3, text: 'Updated learning goal · Daily goal set to 2 lessons', time: 'Yesterday', type: 'goal' }
]

export const WEEKLY_ACTIVITY = [
  { day: 'Mon', minutes: 35 },
  { day: 'Tue', minutes: 50 },
  { day: 'Wed', minutes: 20 },
  { day: 'Thu', minutes: 60 },
  { day: 'Fri', minutes: 45 },
  { day: 'Sat', minutes: 70 },
  { day: 'Sun', minutes: 30 }
]

export const ACHIEVEMENTS_SEED = [
  { id: 1, label: '7 Day Streak', icon: '🔥' },
  { id: 2, label: '30 Lessons Completed', icon: '📘' },
  { id: 3, label: 'First Certificate', icon: '🏅' },
  { id: 4, label: '10 Hours Studied', icon: '⏱️' }
]

export const FAQS = [
  { q: 'How can I reset my password?', a: 'Go to Settings > Account and click "Reset Password". You will receive a reset link by email.' },
  { q: 'How do I enroll in a course?', a: 'Open the Courses page, use the filters to find a course, and click "View Details" then "Enroll".' },
  { q: 'Can I learn more than one language at a time?', a: 'Yes — you can enroll in as many courses as you like and switch between them anytime from My Learning.' },
  { q: 'How can I cancel my subscription?', a: 'Go to Settings > Billing and click "Cancel Plan". Your access continues until the end of the billing period.' }
]

export const LEARN_EXAMPLES = {
  en_es: {
    original: 'I going to school.',
    corrected: 'I am going to school.',
    translated: 'Voy a la escuela.',
    grammarTip: 'Use "am" with "I" to form the present continuous tense. Structure: I am + verb(-ing) + object.',
    vocabulary: [
      { word: 'escuela', meaning: 'school' },
      { word: 'ir', meaning: 'to go' },
      { word: 'estudiar', meaning: 'to study' }
    ],
    pronunciation: 'voy ah lah es-KWEH-lah'
  }
}

export const LOCATIONS = ['Online (All Over India)', 'Hyderabad', 'Vijayawada', 'Guntur', 'Bangalore']

export const RECENT_TRANSLATIONS_SEED = [
  { id: 1, original: 'Good morning!', translated: 'おはようございます！', lang: 'Japanese', time: 'Just now' },
  { id: 2, original: 'Thank you so much.', translated: 'बहुत-बहुत धन्यवाद।', lang: 'Hindi', time: '5 mins ago' },
  { id: 3, original: 'How are you?', translated: 'Comment ça va?', lang: 'French', time: '1 hour ago' }
]

export const PROGRESS_SEED = {
  coursesEnrolled: 2,
  lessonsCompleted: 16,
  streakDays: 5,
  certificates: 1,
  overallProgress: 62
}

export const CONTINUE_LEARNING_SEED = {
  title: 'Japanese for Beginners',
  lesson: 'Lesson 8 of 20',
  progress: 69,
  thumbnail:
    'https://images.unsplash.com/photo-1528360983277-13d401cdc186?w=400&h=300&fit=crop'
}
