import api from './axios'

// Frontend calls our own backend at /api/translate, which proxies to
// LibreTranslate (or any other provider swapped in later) so the API key
// / endpoint never has to live in client code.
export async function translateText({ text, from, to }) {
  const { data } = await api.post('/translate', { text, from, to })
  return data.translatedText
}
