import { createContext, useContext, useEffect, useState } from 'react'
import api from '../api/axios'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('linguahub_token')
    const savedUser = localStorage.getItem('linguahub_user')
    if (token && savedUser) {
      setUser(JSON.parse(savedUser))
    }
    setLoading(false)
  }, [])

  async function login(email, password, remember) {
    const { data } = await api.post('/auth/login', { email, password })
    persistSession(data, remember)
    return data.user
  }

  async function signup(name, email, password) {
    const { data } = await api.post('/auth/register', { name, email, password })
    persistSession(data, true)
    return data.user
  }

  function persistSession(data, remember) {
    const storage = remember ? localStorage : sessionStorage
    storage.setItem('linguahub_token', data.token)
    storage.setItem('linguahub_user', JSON.stringify(data.user))
    localStorage.setItem('linguahub_token', data.token)
    localStorage.setItem('linguahub_user', JSON.stringify(data.user))
    setUser(data.user)
  }

  function logout() {
    localStorage.removeItem('linguahub_token')
    localStorage.removeItem('linguahub_user')
    sessionStorage.removeItem('linguahub_token')
    sessionStorage.removeItem('linguahub_user')
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
