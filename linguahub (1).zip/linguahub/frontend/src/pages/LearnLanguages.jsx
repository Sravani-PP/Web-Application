import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Volume2, Sparkles, BookOpen } from 'lucide-react'
import { LANGUAGES, LEARN_EXAMPLES } from '../data/appData'

export default function LearnLanguages() {
  const { t } = useTranslation()
  const [source, setSource] = useState('en')
  const [target, setTarget] = useState('es')

  const example = LEARN_EXAMPLES.en_es

  function speak(text, lang) {
    const utter = new SpeechSynthesisUtterance(text)
    utter.lang = lang
    window.speechSynthesis.speak(utter)
  }

  return (
    <div className="max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">{t('learn_title')}</h1>
        <p className="text-sm text-slate-400 mt-1">{t('learn_subtitle')}</p>
      </div>

      <div className="card p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div>
            <label className="text-xs font-semibold text-slate-500 mb-1.5 block">From Language</label>
            <select
              value={source}
              onChange={(e) => setSource(e.target.value)}
              className="w-full border border-slate-200 rounded-xl2 px-3 py-2.5 text-sm font-medium bg-white focus:outline-none focus:ring-2 focus:ring-brand-300"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.flag} {l.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 mb-1.5 block">To Language</label>
            <select
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="w-full border border-slate-200 rounded-xl2 px-3 py-2.5 text-sm font-medium bg-white focus:outline-none focus:ring-2 focus:ring-brand-300"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.flag} {l.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Level</label>
            <select className="w-full border border-slate-200 rounded-xl2 px-3 py-2.5 text-sm font-medium bg-white focus:outline-none focus:ring-2 focus:ring-brand-300">
              <option>Beginner</option>
              <option>Intermediate</option>
              <option>Advanced</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="rounded-xl2 border border-red-100 bg-red-50/60 p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-red-500">{t('original')}</p>
              <span className="text-[10px] font-semibold bg-red-100 text-red-500 px-2 py-0.5 rounded-full">Incorrect</span>
            </div>
            <p className="text-sm text-slate-700">{example.original}</p>
          </div>
          <div className="rounded-xl2 border border-emerald-100 bg-emerald-50/60 p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-emerald-600">{t('corrected')}</p>
              <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded-full">Correct</span>
            </div>
            <p className="text-sm text-slate-700">{example.corrected}</p>
          </div>
        </div>

        <div className="rounded-xl2 border border-slate-100 bg-slate-50 p-4 mb-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1">Translated ({LANGUAGES.find((l) => l.code === target)?.name})</p>
            <p className="text-sm font-medium text-slate-800">{example.translated}</p>
          </div>
          <button
            onClick={() => speak(example.translated, target)}
            className="w-9 h-9 rounded-full bg-white border border-slate-200 flex items-center justify-center text-brand-500 hover:bg-brand-50"
          >
            <Volume2 size={16} />
          </button>
        </div>

        <div className="rounded-xl2 bg-brand-50 p-4 mb-6">
          <div className="flex items-center gap-2 text-brand-700 font-semibold text-sm mb-1">
            <Sparkles size={16} /> {t('grammarTip')}
          </div>
          <p className="text-sm text-slate-600">{example.grammarTip}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 className="flex items-center gap-2 font-semibold text-slate-900 text-sm mb-3">
              <BookOpen size={16} className="text-brand-500" /> {t('vocabulary')}
            </h3>
            <ul className="space-y-2">
              {example.vocabulary.map((v) => (
                <li key={v.word} className="flex items-center justify-between text-sm bg-slate-50 rounded-xl2 px-3 py-2">
                  <span className="font-medium text-slate-800">{v.word}</span>
                  <span className="text-slate-400">{v.meaning}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-slate-900 text-sm mb-3">{t('pronunciation')}</h3>
            <div className="bg-slate-50 rounded-xl2 px-3 py-2 text-sm text-slate-600 flex items-center justify-between">
              <span>{example.pronunciation}</span>
              <button
                onClick={() => speak(example.translated, target)}
                className="text-brand-500 hover:text-brand-600"
              >
                <Volume2 size={16} />
              </button>
            </div>
          </div>
        </div>

        <button className="btn-primary px-8 py-2.5">{t('practiceNow')}</button>
      </div>
    </div>
  )
}
