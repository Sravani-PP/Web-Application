import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import TranslatorCard from '../components/TranslatorCard'
import RecentTranslations from '../components/RecentTranslations'
import { RECENT_TRANSLATIONS_SEED, LANGUAGES } from '../data/appData'

export default function Translator() {
  const { t } = useTranslation()
  const [history, setHistory] = useState(RECENT_TRANSLATIONS_SEED)

  function handleTranslated({ original, translated, to }) {
    const langName = LANGUAGES.find((l) => l.code === to)?.name || to
    setHistory((prev) => [
      { id: Date.now(), original, translated, lang: langName, time: 'Just now' },
      ...prev
    ])
  }

  return (
    <div className="max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">{t('translator_title')}</h1>
        <p className="text-sm text-slate-400 mt-1">{t('translator_subtitle')}</p>
      </div>

      <TranslatorCard onTranslated={handleTranslated} />

      <div>
        <h2 className="font-bold text-slate-900 mb-3">{t('translationHistory')}</h2>
        <RecentTranslations items={history} onClear={() => setHistory([])} />
      </div>
    </div>
  )
}
