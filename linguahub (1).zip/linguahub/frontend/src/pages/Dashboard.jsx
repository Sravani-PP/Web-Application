import { useTranslation } from 'react-i18next'
import { GraduationCap, CheckCircle2, Flame, Award, CheckCircle, PenLine, Target } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { PROGRESS_SEED, ENROLLED_COURSES, RECENT_ACTIVITY } from '../data/appData'

function getGreetingKey() {
  const hour = new Date().getHours()
  if (hour < 12) return 'greeting_morning'
  if (hour < 17) return 'greeting_afternoon'
  return 'greeting_evening'
}

const ACTIVITY_ICON = { done: CheckCircle, practice: PenLine, goal: Target }

export default function Dashboard() {
  const { t } = useTranslation()
  const { user } = useAuth()
  const active = ENROLLED_COURSES[0]

  const cards = [
    { icon: GraduationCap, label: t('card_totalCourses'), value: PROGRESS_SEED.coursesEnrolled, color: 'text-brand-500', bg: 'bg-brand-50' },
    { icon: CheckCircle2, label: t('card_lessonsCompleted'), value: PROGRESS_SEED.lessonsCompleted, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { icon: Flame, label: t('card_learningStreak'), value: `${PROGRESS_SEED.streakDays} Days`, color: 'text-orange-500', bg: 'bg-orange-50' },
    { icon: Award, label: t('card_certificatesEarned'), value: PROGRESS_SEED.certificates, color: 'text-purple-500', bg: 'bg-purple-50' }
  ]

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">
          👋 {t(getGreetingKey())}, {user?.name?.split(' ')[0] || 'Sravani'}!
        </h1>
        <p className="text-sm text-slate-400 mt-1">Let's continue your language learning journey today.</p>
      </div>

      <div className="card p-5 flex items-start gap-4 bg-gradient-to-br from-brand-50/60 to-white">
        <div className="w-11 h-11 rounded-xl2 bg-brand-gradient flex items-center justify-center text-white flex-shrink-0">
          🌐
        </div>
        <div>
          <h2 className="font-bold text-slate-900 mb-1">About LinguaHub</h2>
          <p className="text-sm text-slate-500 leading-relaxed">{t('dashboard_bio')}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cards.map(({ icon: Icon, label, value, color, bg }) => (
          <div key={label} className="card p-5">
            <div className={`w-10 h-10 rounded-xl2 ${bg} ${color} flex items-center justify-center mb-3`}>
              <Icon size={18} />
            </div>
            <p className="text-xl font-bold text-slate-900">{value}</p>
            <p className="text-xs text-slate-400 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-5">
          <h3 className="font-bold text-slate-900 mb-4">{t('continueLearning')}</h3>
          <div className="flex gap-4">
            <img src={active.thumbnail} alt={active.title} className="w-20 h-20 rounded-xl2 object-cover flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-slate-900 text-sm">{active.title}</p>
              <p className="text-xs text-slate-400 mb-2">{active.currentLesson}</p>
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden mb-1">
                <div className="h-full bg-brand-gradient rounded-full" style={{ width: `${active.progress}%` }} />
              </div>
              <p className="text-xs text-slate-400 mb-3">{active.progress}%</p>
              <button className="btn-primary text-xs py-2 px-4">{t('resumeLearning')}</button>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-900">{t('recentActivity')}</h3>
            <button className="text-xs font-semibold text-brand-600">{t('viewAll')}</button>
          </div>
          <ul className="space-y-3">
            {RECENT_ACTIVITY.map((item) => {
              const Icon = ACTIVITY_ICON[item.type]
              return (
                <li key={item.id} className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-full bg-brand-50 text-brand-500 flex items-center justify-center flex-shrink-0">
                    <Icon size={14} />
                  </div>
                  <div>
                    <p className="text-sm text-slate-700">{item.text}</p>
                    <p className="text-xs text-slate-400">{item.time}</p>
                  </div>
                </li>
              )
            })}
          </ul>
        </div>
      </div>

      <p className="text-center text-xs text-slate-400 italic">
        "The limits of my language mean the limits of my world." — Ludwig Wittgenstein
      </p>
    </div>
  )
}
