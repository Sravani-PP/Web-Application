import { useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Star } from 'lucide-react'
import toast from 'react-hot-toast'
import { COURSES, LEVELS, MODES_FILTER, COURSE_LANGUAGES } from '../data/appData'

const BUDGETS = [
  { label: 'Any Budget', min: 0, max: Infinity },
  { label: 'Under ₹1,000', min: 0, max: 1000 },
  { label: '₹1,000 – ₹2,000', min: 1000, max: 2000 },
  { label: 'Above ₹2,000', min: 2000, max: Infinity }
]

export default function Courses() {
  const { t } = useTranslation()
  const [language, setLanguage] = useState('All')
  const [level, setLevel] = useState('All')
  const [budget, setBudget] = useState(0)
  const [mode, setMode] = useState('All')

  const filtered = useMemo(() => {
    const b = BUDGETS[budget]
    return COURSES.filter((c) => {
      if (language !== 'All' && c.language !== language) return false
      if (level !== 'All' && c.level !== level) return false
      if (mode !== 'All' && c.mode !== mode) return false
      if (c.price < b.min || c.price > b.max) return false
      return true
    }).sort((a, b2) => a.price - b2.price)
  }, [language, level, budget, mode])

  return (
    <div className="max-w-6xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">{t('courses_title')}</h1>
        <p className="text-sm text-slate-400 mt-1">{t('courses_subtitle')}</p>
      </div>

      <div className="card p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
        <FilterSelect label={t('filter_language')} value={language} onChange={setLanguage} options={['All', ...COURSE_LANGUAGES]} />
        <FilterSelect label={t('filter_level')} value={level} onChange={setLevel} options={['All', ...LEVELS]} />
        <FilterSelect
          label={t('filter_budget')}
          value={budget}
          onChange={(v) => setBudget(Number(v))}
          options={BUDGETS.map((b, i) => ({ label: b.label, value: i }))}
          isObjectOptions
        />
        <FilterSelect label={t('filter_mode')} value={mode} onChange={setMode} options={['All', ...MODES_FILTER]} />
        <button className="btn-primary py-2.5">{t('findCourses')}</button>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-slate-900">{t('recommended')}</h2>
          <span className="text-xs text-slate-400">{filtered.length} course{filtered.length !== 1 ? 's' : ''} found</span>
        </div>

        {filtered.length === 0 ? (
          <div className="card p-10 text-center text-sm text-slate-400">
            No courses match these filters — try widening your budget or level.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((course) => (
              <div key={course.id} className="card p-5 flex flex-col hover:shadow-card transition-shadow">
                <div className="flex items-center justify-between mb-3">
                  <span className={`text-white text-[11px] font-semibold px-2.5 py-1 rounded-full ${course.badgeColor}`}>
                    {course.level}
                  </span>
                  <span className="text-[11px] font-medium text-slate-400">{course.mode}</span>
                </div>

                <div className={`w-full h-28 rounded-xl2 bg-gradient-to-br ${course.avatarBg} flex items-center justify-center text-4xl mb-4`}>
                  {course.emoji}
                </div>

                <h3 className="font-bold text-slate-900">{course.title}</h3>
                <p className="text-xs text-slate-400 mt-1 mb-2">{course.description}</p>

                <div className="flex items-center gap-1 text-xs text-amber-500 mb-3">
                  <Star size={12} fill="currentColor" /> {course.rating}
                  <span className="text-slate-300">·</span>
                  <span className="text-slate-400">{course.platform}</span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs text-slate-400">{course.lessons} Lessons</span>
                  <span className="font-bold text-slate-900">₹{course.price.toLocaleString('en-IN')}</span>
                </div>

                <button
                  onClick={() => toast.success(`Enrolled in ${course.title}!`)}
                  className="mt-auto btn-primary text-sm py-2.5"
                >
                  {t('viewDetails')}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function FilterSelect({ label, value, onChange, options, isObjectOptions }) {
  return (
    <div>
      <label className="text-xs font-semibold text-slate-500 mb-1.5 block">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border border-slate-200 rounded-xl2 px-3 py-2.5 text-sm font-medium bg-white focus:outline-none focus:ring-2 focus:ring-brand-300"
      >
        {isObjectOptions
          ? options.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))
          : options.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
      </select>
    </div>
  )
}
