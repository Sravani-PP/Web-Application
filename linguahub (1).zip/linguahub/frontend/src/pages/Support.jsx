import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Mail, Phone, MessageCircle, MessagesSquare, ChevronDown } from 'lucide-react'
import toast from 'react-hot-toast'
import { FAQS } from '../data/appData'

export default function Support() {
  const { t } = useTranslation()
  const [openFaq, setOpenFaq] = useState(null)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const contactCards = [
    { icon: Mail, title: t('emailUs'), value: 'support@linguahub.com', note: 'We will respond within 24 hours.', color: 'text-brand-500', bg: 'bg-brand-50' },
    { icon: Phone, title: t('callUs'), value: '+91 98765 43210', note: 'Mon – Sat (9 AM – 6 PM)', color: 'text-blue-500', bg: 'bg-blue-50' },
    { icon: MessageCircle, title: t('whatsapp'), value: '+91 98765 43210', note: 'Chat with us on WhatsApp', color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { icon: MessagesSquare, title: t('liveChat'), value: 'Available', note: 'Chat with our support team', color: 'text-purple-500', bg: 'bg-purple-50' }
  ]

  function handleSubmit(e) {
    e.preventDefault()
    if (!name || !email || !message) {
      toast.error('Please fill in all fields.')
      return
    }
    toast.success('Message sent! We will get back to you soon.')
    setName('')
    setEmail('')
    setMessage('')
  }

  return (
    <div className="max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">{t('support_title')}</h1>
        <p className="text-sm text-slate-400 mt-1">{t('support_subtitle')}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {contactCards.map(({ icon: Icon, title, value, note, color, bg }) => (
          <div key={title} className="card p-5">
            <div className={`w-10 h-10 rounded-xl2 ${bg} ${color} flex items-center justify-center mb-3`}>
              <Icon size={18} />
            </div>
            <p className="font-semibold text-slate-900 text-sm">{title}</p>
            <p className="text-sm text-slate-700 mt-1">{value}</p>
            <p className="text-xs text-slate-400 mt-1">{note}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-900">{t('faqs')}</h3>
            <button className="text-xs font-semibold text-brand-600">{t('viewAll')} FAQs</button>
          </div>
          <ul className="divide-y divide-slate-100">
            {FAQS.map((faq, i) => (
              <li key={faq.q} className="py-3">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between text-left text-sm font-medium text-slate-700"
                >
                  {faq.q}
                  <ChevronDown
                    size={16}
                    className={`text-slate-400 transition-transform ${openFaq === i ? 'rotate-180' : ''}`}
                  />
                </button>
                {openFaq === i && <p className="text-xs text-slate-400 mt-2 leading-relaxed">{faq.a}</p>}
              </li>
            ))}
          </ul>
        </div>

        <div className="card p-5">
          <h3 className="font-bold text-slate-900 mb-4">{t('sendMessage')}</h3>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your Name"
                className="border border-slate-200 rounded-xl2 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300"
              />
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your Email"
                type="email"
                className="border border-slate-200 rounded-xl2 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300"
              />
            </div>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Your Message"
              rows={5}
              className="w-full resize-none border border-slate-200 rounded-xl2 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300"
            />
            <button type="submit" className="btn-primary w-full py-2.5">
              {t('sendMessage')}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
