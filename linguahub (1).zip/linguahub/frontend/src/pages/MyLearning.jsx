import { useTranslation } from 'react-i18next'
import toast from 'react-hot-toast'
import { ENROLLED_COURSES, PROGRESS_SEED } from '../data/appData'

export default function MyLearning() {
  const { t } = useTranslation()
  const dailyGoal = { completed: 1, target: 2 }

  return (
    <div className="max-w-5xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">{t('myLearning_title')}</h1>
        <p className="text-sm text-slate-400 mt-1">{t('myLearning_subtitle')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-6">
        <div className="space-y-4">
          {ENROLLED_COURSES.map((course) => (
            <div key={course.id} className="card p-5 flex flex-col sm:flex-row gap-4 sm:items-center">
              <img src={course.thumbnail} alt={course.title} className="w-20 h-20 rounded-xl2 object-cover flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-slate-900">{course.title}</p>
                <p className="text-xs text-slate-400 mb-2">{course.currentLesson}</p>
                <div className="h-2 rounded-full bg-slate-100 overflow-hidden mb-1">
                  <div className="h-full bg-brand-gradient rounded-full" style={{ width: `${course.progress}%` }} />
                </div>
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>{course.progress}% complete</span>
                  <span>Last studied {course.lastStudied}</span>
                </div>
              </div>
              <button
                onClick={() => toast.success(`Resuming ${course.title}...`)}
                className="btn-primary text-sm py-2 px-5 flex-shrink-0"
              >
                {t('resume')}
              </button>
            </div>
          ))}
        </div>

        <div className="space-y-6">
          <div className="card p-5 text-center">
            <h3 className="font-bold text-slate-900 mb-4 text-left">{t('dailyGoal')}</h3>
            <div className="relative w-28 h-28 mx-auto mb-3">
              <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#f1f5f9"
                  strokeWidth="3"
                />
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="url(#grad)"
                  strokeWidth="3"
                  strokeDasharray={`${(dailyGoal.completed / dailyGoal.target) * 100}, 100`}
                  strokeLinecap="round"
                />
                <defs>
                  <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#7c4dff" />
                    <stop offset="100%" stopColor="#3b82f6" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xl font-bold text-slate-900">
                  {dailyGoal.completed}/{dailyGoal.target}
                </span>
                <span className="text-[10px] text-slate-400">Lessons</span>
              </div>
            </div>
            <p className="text-xs text-slate-400">Great! Keep it up.</p>
          </div>

          <div className="card p-5">
            <h3 className="font-bold text-slate-900 mb-3">Study Reminders</h3>
            <div className="flex items-center justify-between text-sm mb-3">
              <span className="text-slate-500">Daily reminder</span>
              <span className="text-slate-800 font-medium">7:00 PM</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">Weekly summary</span>
              <span className="text-slate-800 font-medium">Every Sunday</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
