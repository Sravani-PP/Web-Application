import { Sparkles } from 'lucide-react'

export default function ComingSoon({ title }) {
  return (
    <div className="max-w-3xl">
      <div className="card p-12 text-center">
        <div className="w-14 h-14 rounded-xl2 bg-brand-gradient text-white flex items-center justify-center mx-auto mb-4">
          <Sparkles size={22} />
        </div>
        <h1 className="text-xl font-bold text-slate-900 mb-2">{title}</h1>
        <p className="text-sm text-slate-400">This section is coming soon.</p>
      </div>
    </div>
  )
}
