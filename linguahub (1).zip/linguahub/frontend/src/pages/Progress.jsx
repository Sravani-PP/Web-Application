import { useTranslation } from 'react-i18next'
import { BarChart, Bar, XAxis, ResponsiveContainer, Tooltip } from 'recharts'
import { Flame, Clock, CheckCircle2, TrendingUp } from 'lucide-react'
import { PROGRESS_SEED, WEEKLY_ACTIVITY, ACHIEVEMENTS_SEED } from '../data/appData'

export default function ProgressPage() {
  const { t } = useTranslation()
  const totalMinutes = WEEKLY_ACTIVITY.reduce((sum, d) => sum + d.minutes, 0)
  const hours = Math.floor(totalMinutes / 60)
  const mins = totalMinutes % 60

  const stats = [
    { icon: Flame, label: t('currentStreak'), value: `${PROGRESS_SEED.streakDays} Days`, color: 'text-orange-500', bg: 'bg-orange-50' },
    { icon: Clock, label: t('studyTime'), value: `${hours}h ${mins}m`, color: 'text-brand-500', bg: 'bg-brand-50' },
    { icon: CheckCircle2, label: t('completed'), value: PROGRESS_SEED.lessonsCompleted, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { icon: TrendingUp, label: t('overall'), value: `${PROGRESS_SEED.overallProgress}%`, color: 'text-purple-500', bg: 'bg-purple-50' }
  ]

  return (
    <div className="max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">{t('progress_title')}</h1>
        <p className="text-sm text-slate-400 mt-1">{t('progress_subtitle')}</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map(({ icon: Icon, label, value, color, bg }) => (
          <div key={label} className="card p-5">
            <div className={`w-10 h-10 rounded-xl2 ${bg} ${color} flex items-center justify-center mb-3`}>
              <Icon size={18} />
            </div>
            <p className="text-xl font-bold text-slate-900">{value}</p>
            <p className="text-xs text-slate-400 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
        <div className="card p-5">
          <h3 className="font-bold text-slate-900 mb-4">{t('weeklyActivity')}</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={WEEKLY_ACTIVITY}>
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                <Tooltip
                  cursor={{ fill: '#f4f2ff' }}
                  contentStyle={{ borderRadius: 12, border: '1px solid #ece8ff', fontSize: 12 }}
                  formatter={(v) => [`${v} min`, 'Studied']}
                />
                <Bar dataKey="minutes" fill="#7c4dff" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-5">
          <h3 className="font-bold text-slate-900 mb-4">{t('achievements')}</h3>
          <ul className="space-y-3">
            {ACHIEVEMENTS_SEED.map((a) => (
              <li key={a.id} className="flex items-center gap-3 bg-slate-50 rounded-xl2 px-3 py-2.5">
                <span className="text-xl">{a.icon}</span>
                <span className="text-sm font-medium text-slate-700">{a.label}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
