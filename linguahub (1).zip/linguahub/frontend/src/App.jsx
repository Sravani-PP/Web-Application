import { Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import Login from './pages/Login'
import Signup from './pages/Signup'
import DashboardLayout from './pages/DashboardLayout'
import Dashboard from './pages/Dashboard'
import Translator from './pages/Translator'
import LearnLanguages from './pages/LearnLanguages'
import Courses from './pages/Courses'
import MyLearning from './pages/MyLearning'
import ProgressPage from './pages/Progress'
import Support from './pages/Support'
import ComingSoon from './pages/ComingSoon'
import { useAuth } from './context/AuthContext'

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return null
  return user ? children : <Navigate to="/login" replace />
}

export default function App() {
  return (
    <>
      <Toaster position="top-right" toastOptions={{ style: { fontSize: '14px' } }} />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        <Route
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/translator" element={<Translator />} />
          <Route path="/learn" element={<LearnLanguages />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/my-learning" element={<MyLearning />} />
          <Route path="/progress" element={<ProgressPage />} />
          <Route path="/support" element={<Support />} />
          <Route path="/practice" element={<ComingSoon title="Practice" />} />
          <Route path="/certificates" element={<ComingSoon title="Certificates" />} />
          <Route path="/community" element={<ComingSoon title="Community" />} />
          <Route path="/settings" element={<ComingSoon title="Settings" />} />
        </Route>

        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </>
  )
}
