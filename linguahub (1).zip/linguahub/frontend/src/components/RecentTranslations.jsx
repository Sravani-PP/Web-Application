import { ArrowRight, Trash2 } from 'lucide-react'

const DOT_COLORS = ['bg-emerald-100 text-emerald-600', 'bg-orange-100 text-orange-600', 'bg-blue-100 text-blue-600']

export default function RecentTranslations({ items, onClear }) {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-slate-900 text-sm">Recent Translations</h3>
        <button className="text-xs font-semibold text-brand-600">View All</button>
      </div>

      {items.length === 0 ? (
        <p className="text-sm text-slate-400 py-6 text-center">
          No translations yet — try the translator above.
        </p>
      ) : (
        <ul className="space-y-3">
          {items.map((item, i) => (
            <li key={item.id} className="flex items-start gap-3">
              <span
                className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  DOT_COLORS[i % DOT_COLORS.length]
                }`}
              >
                {item.lang[0]}
              </span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 text-sm text-slate-700">
                  <span className="truncate">{item.original}</span>
                  <ArrowRight size={12} className="text-slate-300 flex-shrink-0" />
                  <span className="truncate font-medium">{item.translated}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {item.lang} • {item.time}
                </p>
              </div>
            </li>
          ))}
        </ul>
      )}

      <button
        onClick={onClear}
        className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-red-500 mt-4"
      >
        <Trash2 size={13} /> Clear History
      </button>
    </div>
  )
}
