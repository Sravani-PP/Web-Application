import { Search, Bell, ChevronDown, Menu, Globe } from 'lucide-react'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useAuth } from '../context/AuthContext'
import { UI_LANGUAGES } from '../data/appData'

export default function Navbar({ onMenuClick }) {
  const { user, logout } = useAuth()
  const { i18n } = useTranslation()
  const [menuOpen, setMenuOpen] = useState(false)
  const [langOpen, setLangOpen] = useState(false)

  const currentLang = UI_LANGUAGES.find((l) => l.code === i18n.language) || UI_LANGUAGES[0]

  function changeLanguage(code) {
    i18n.changeLanguage(code)
    setLangOpen(false)
  }

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-slate-100 px-4 lg:px-8 py-3 flex items-center gap-4">
      <button className="lg:hidden text-slate-500" onClick={onMenuClick}>
        <Menu size={22} />
      </button>

      <div className="flex-1 max-w-xl relative">
        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          placeholder="Search for courses, lessons, or anything..."
          className="w-full bg-slate-50 border border-slate-100 rounded-xl2 pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300"
        />
      </div>

      <div className="relative hidden md:block">
        <button
          onClick={() => setLangOpen((v) => !v)}
          className="flex items-center gap-1.5 text-sm font-medium text-slate-600 bg-slate-50 border border-slate-100 rounded-xl2 px-3 py-2"
        >
          <Globe size={16} /> {currentLang.name} <ChevronDown size={14} />
        </button>
        {langOpen && (
          <div className="absolute right-0 mt-2 w-40 bg-white rounded-xl2 shadow-card border border-slate-100 py-1 text-sm z-40">
            {UI_LANGUAGES.map((lang) => (
              <button
                key={lang.code}
                onClick={() => changeLanguage(lang.code)}
                className={`w-full text-left px-4 py-2 hover:bg-slate-50 ${
                  lang.code === currentLang.code ? 'text-brand-600 font-semibold' : 'text-slate-600'
                }`}
              >
                {lang.name}
              </button>
            ))}
          </div>
        )}
      </div>

      <button className="relative text-slate-500 hover:text-slate-800">
        <Bell size={20} />
        <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-red-500" />
      </button>

      <div className="relative">
        <button onClick={() => setMenuOpen((v) => !v)} className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-full bg-brand-gradient text-white flex items-center justify-center font-semibold text-sm">
            {(user?.name || 'S')[0].toUpperCase()}
          </div>
          <div className="hidden sm:block text-left">
            <p className="text-sm font-semibold text-slate-800 leading-tight">{user?.name || 'Sravani'}</p>
            <p className="text-xs text-slate-400 leading-tight">Language Learner</p>
          </div>
          <ChevronDown size={14} className="text-slate-400 hidden sm:block" />
        </button>
        {menuOpen && (
          <div className="absolute right-0 mt-2 w-40 bg-white rounded-xl2 shadow-card border border-slate-100 py-1 text-sm z-40">
            <button className="w-full text-left px-4 py-2 hover:bg-slate-50">Profile</button>
            <button className="w-full text-left px-4 py-2 hover:bg-slate-50">Settings</button>
            <button onClick={logout} className="w-full text-left px-4 py-2 hover:bg-slate-50 text-red-500">
              Log out
            </button>
          </div>
        )}
      </div>
    </header>
  )
}
