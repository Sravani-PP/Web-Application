import { NavLink } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  LayoutDashboard,
  Languages,
  BookOpen,
  GraduationCap,
  PenLine,
  Award,
  TrendingUp,
  Users,
  LifeBuoy,
  Settings,
  Crown,
  X,
  MessagesSquare
} from 'lucide-react'

const NAV_ITEMS = [
  { icon: LayoutDashboard, key: 'nav_dashboard', to: '/dashboard' },
  { icon: Languages, key: 'nav_translator', to: '/translator' },
  { icon: BookOpen, key: 'nav_learn', to: '/learn' },
  { icon: GraduationCap, key: 'nav_courses', to: '/courses' },
  { icon: PenLine, key: 'nav_myLearning', to: '/my-learning' },
  { icon: MessagesSquare, key: 'nav_practice', to: '/practice' },
  { icon: Award, key: 'nav_certificates', to: '/certificates' },
  { icon: TrendingUp, key: 'nav_progress', to: '/progress' },
  { icon: Users, key: 'nav_community', to: '/community' },
  { icon: LifeBuoy, key: 'nav_support', to: '/support' },
  { icon: Settings, key: 'nav_settings', to: '/settings' }
]

export default function Sidebar({ open, onClose }) {
  const { t } = useTranslation()

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/30 z-40 lg:hidden" onClick={onClose} />}
      <aside
        className={`fixed lg:sticky top-0 z-50 h-screen w-72 bg-white border-r border-slate-100 flex flex-col transition-transform duration-200 ${
          open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl2 bg-brand-gradient flex items-center justify-center text-white font-bold">
              L
            </div>
            <div>
              <p className="font-bold text-slate-900 leading-tight">LinguaHub</p>
              <p className="text-[11px] text-slate-400 leading-tight">Learn. Translate. Grow.</p>
            </div>
          </div>
          <button className="lg:hidden text-slate-400" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 space-y-1">
          {NAV_ITEMS.map(({ icon: Icon, key, to }) => (
            <NavLink
              key={key}
              to={to}
              onClick={onClose}
              className={({ isActive }) =>
                `w-full flex items-center gap-3 px-4 py-2.5 rounded-xl2 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-brand-gradient text-white shadow-pop'
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                }`
              }
            >
              <Icon size={18} />
              {t(key)}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 space-y-4">
          <div className="rounded-xl3 bg-gradient-to-br from-brand-500/10 to-blueAccent/10 border border-brand-100 p-4">
            <div className="flex items-center gap-2 text-amber-500 font-semibold text-sm mb-2">
              <Crown size={16} /> Go Pro
            </div>
            <ul className="text-xs text-slate-500 space-y-1 mb-3">
              <li>✓ Unlimited Translations</li>
              <li>✓ All Premium Courses</li>
              <li>✓ 1-1 Expert Guidance</li>
              <li>✓ Certificates</li>
            </ul>
            <button className="btn-primary w-full text-sm py-2">Upgrade Now</button>
          </div>
        </div>
      </aside>
    </>
  )
}
