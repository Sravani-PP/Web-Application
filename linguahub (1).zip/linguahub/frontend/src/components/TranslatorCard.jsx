import { useState } from 'react'
import { ArrowLeftRight, Copy, Volume2, Trash2, Sparkles, Mic } from 'lucide-react'
import toast from 'react-hot-toast'
import { LANGUAGES, POPULAR_PAIRS } from '../data/appData'
import { translateText } from '../api/translate'

export default function TranslatorCard({ onTranslated }) {
  const [from, setFrom] = useState('en')
  const [to, setTo] = useState('ja')
  const [input, setInput] = useState('Hello! How are you today?')
  const [output, setOutput] = useState('')
  const [loading, setLoading] = useState(false)

  const charLimit = 500

  async function handleTranslate() {
    if (!input.trim()) {
      toast.error('Type something to translate first.')
      return
    }
    setLoading(true)
    try {
      const result = await translateText({ text: input, from, to })
      setOutput(result)
      onTranslated?.({ original: input, translated: result, to })
      toast.success('Translated!')
    } catch (err) {
      toast.error('Translation failed. Check your backend / API connection.')
    } finally {
      setLoading(false)
    }
  }

  function handleSwap() {
    setFrom(to)
    setTo(from)
    setInput(output)
    setOutput(input)
  }

  function handleCopy() {
    if (!output) return
    navigator.clipboard.writeText(output)
    toast.success('Copied to clipboard')
  }

  function handleSpeak() {
    if (!output) return
    const utter = new SpeechSynthesisUtterance(output)
    utter.lang = to
    window.speechSynthesis.speak(utter)
  }

  function handleClear() {
    setInput('')
    setOutput('')
  }

  function applyPair(pair) {
    setFrom(pair.from)
    setTo(pair.to)
  }

  return (
    <div className="card p-6">
      <div className="flex items-center gap-2 mb-1">
        <Sparkles size={20} className="text-brand-500" />
        <h2 className="text-xl font-bold text-slate-900">Translation Tool</h2>
      </div>
      <p className="text-sm text-slate-400 mb-5">
        Translate any message from one language to another instantly
      </p>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-4 items-center mb-5">
        <LanguageSelect label="From" value={from} onChange={setFrom} />
        <button
          onClick={handleSwap}
          className="mx-auto mt-5 md:mt-6 w-10 h-10 rounded-full bg-brand-50 text-brand-600 flex items-center justify-center hover:bg-brand-100 transition-colors"
          aria-label="Swap languages"
        >
          <ArrowLeftRight size={18} />
        </button>
        <LanguageSelect label="To" value={to} onChange={setTo} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value.slice(0, charLimit))}
            rows={5}
            placeholder="Type to translate..."
            className="w-full resize-none rounded-xl2 border border-slate-100 bg-slate-50 p-4 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300"
          />
          <div className="flex items-center justify-between mt-2 px-1">
            <button className="text-slate-400 hover:text-brand-500">
              <Mic size={16} />
            </button>
            <span className="text-xs text-slate-400">
              {input.length}/{charLimit}
            </span>
          </div>
        </div>

        <div className="relative">
          <textarea
            value={output}
            readOnly
            rows={5}
            placeholder="Translation will appear here..."
            className="w-full resize-none rounded-xl2 border border-slate-100 bg-white p-4 text-sm focus:outline-none"
          />
          <div className="flex items-center gap-3 mt-2 px-1">
            <button onClick={handleCopy} className="text-slate-400 hover:text-brand-500">
              <Copy size={16} />
            </button>
            <button onClick={handleSpeak} className="text-slate-400 hover:text-brand-500">
              <Volume2 size={16} />
            </button>
            <button onClick={handleClear} className="text-slate-400 hover:text-red-500 ml-auto">
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      </div>

      <button
        onClick={handleTranslate}
        disabled={loading}
        className="btn-primary w-full md:w-auto md:px-10 mt-5 flex items-center justify-center gap-2"
      >
        <Sparkles size={16} /> {loading ? 'Translating...' : 'Translate'}
      </button>

      <div className="flex flex-wrap items-center gap-2 mt-6">
        <span className="text-sm font-medium text-slate-500">Popular:</span>
        {POPULAR_PAIRS.map((pair) => (
          <button
            key={pair.label}
            onClick={() => applyPair(pair)}
            className="text-xs font-medium px-3 py-1.5 rounded-full border border-slate-200 text-slate-500 hover:border-brand-300 hover:text-brand-600 transition-colors"
          >
            {pair.label}
          </button>
        ))}
      </div>
    </div>
  )
}

function LanguageSelect({ label, value, onChange }) {
  return (
    <div>
      <label className="text-xs font-semibold text-slate-500 mb-1.5 block">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border border-slate-200 rounded-xl2 px-3 py-2.5 text-sm font-medium bg-white focus:outline-none focus:ring-2 focus:ring-brand-300"
      >
        {LANGUAGES.map((lang) => (
          <option key={lang.code} value={lang.code}>
            {lang.flag} {lang.name}
          </option>
        ))}
      </select>
    </div>
  )
}
