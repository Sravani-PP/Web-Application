/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif']
      },
      colors: {
        brand: {
          50: '#f4f2ff',
          100: '#ece8ff',
          200: '#d9d1ff',
          300: '#b9a9ff',
          400: '#9678ff',
          500: '#7c4dff',
          600: '#6b32f0',
          700: '#5a24cc',
          800: '#4a1ea6',
          900: '#3d1b85'
        },
        blueAccent: '#3b82f6'
      },
      borderRadius: {
        xl2: '20px',
        xl3: '24px'
      },
      boxShadow: {
        soft: '0 2px 10px rgba(30, 20, 80, 0.06)',
        card: '0 4px 20px rgba(30, 20, 80, 0.08)',
        pop: '0 10px 30px rgba(76, 29, 214, 0.18)'
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(135deg, #7c4dff 0%, #4f46e5 50%, #3b82f6 100%)'
      }
    }
  },
  plugins: []
}
